#Forest class, employs the decision Tree class to form many trees and 
#average their results
from Tree import Tree

class Forest:

    #forest contains two lists, one to hold the trees, and one to hold the
    #predictions of these trees
    def __init__(self, trees=[], returns=[]):
        self.trees = trees
        self.returns = returns
    
    #builds a forest of trees using the create_tree method from the Tree 
    #class
    def build_forest(self, values, rands, forest_size):
        for i in range(0, forest_size):
            temp = Tree()
            temp.create_tree(values[:], rands[:])
            self.trees.append(temp)
            temp = None
    
    #tests the trees in a created forest on a given instance
    def test_forest(self, instance):
        for i in range(0, len(self.trees)):
            temp = self.trees[i]
            x = temp.test_instance(temp.root, instance)
            self.returns.append(x)

    #totals the different possible predictions made for the given instance,
    #and returns a message based on the majority
    def return_prediction(self):
        g = 0
        b = 0
        x = 0
        for i in range(0, len(self.returns)):
            if self.returns[i] == 'g':
                g+=1
            elif self.returns[i] == 'b':
                b+=1
            else:
                x+=1
        if g > b:
            if g > x:
                print("This instance returned a majority GOOD prediction")
            else:
                print("This instance is novel to the dataset and cannot have its value predicted accurately")
        else:
            if b > x:
                print("This instance returned a majority BAD prediction")
            else:
                print("This instance is novel to the dataset and cannot have its value predicted accurately")