#Node class for decision tree
class Node:
    
    #Node can take values, left and right child nodes if not a leaf,
    #split_m and split_val for the feature and value of the split at each
    #node, and leaf and predictor variables for if the node is a leaf, and
    #what prediction that leaf would return
    def __init__(self, values=None, left=None, right=None, split_m=None, split_val=None, leaf=False, predictor=None):
        self.values = values
        self.left = left
        self.right = right
        self.split_m = split_m
        self.split_val = split_val
        self.leaf = leaf
        self.predictor = predictor