Overview
For this project, I chose to implement a multi-level class structure to form
the random forest required for prediction. This allowed for a cleaner
implementation of the recursive calls needed to create the trees within the
forest, and for a simplified and clear main project file.
I found that it was much more difficult to predict a bad instance than a good
one.

Decision Points
	Splits (%b^2 + %g^2)
	To choose where to put the splits, I tried to form a value that would
	incorporate the percentages of both b and g in a list after some split.
	This led me to use the sum of the percentages of b and g in the 
	given list as a split evaluator.
	
	m (about 15)
	I found that using under 10 random values to generate a tree often
	led to false predictions, with almost every tree returning 'good'.
	When going over 10, 'bad' starts to return more frequently from the
	tree for bad instances, with a majority forming as around 15 instances
	are used.

	size of the forest (N/A)
	The size of the forest would typically allow for a more varied set of results
	when testing an instance on the forest. However, despite my best
	efforts to ensure that each tree is created randomly, it appears that
	my forest almost always returns a 100% answer of bad or good. If 
	the prediction is 'good' for one tree, it is good for all, and vice
	versa.
	I am unsure if this is the nature of the data, but this seemed off to me.