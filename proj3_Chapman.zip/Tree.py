#Decision Tree class, uses Node class to build structure of connected nodes
from Node import Node

class Tree:
    #intializes tree through its root
    #tree has a max depth set here, and a limit for the length of a list
    #at a node before it is considered a leaf
    def __init__(self, maxdepth=6, minsamples=10):
        self.maxdepth = maxdepth
        self.minsamples = minsamples
        self.root = None

    #function to get a value for split percentage
    #takes in list to split at the given split value, and returns a value
    #equal to the sum of the two weighted probability values, with a value
    #calculated for each of the lists formed by the split
    def get_maj_percent(self, split, values, m):
        vals = len(values)
        top = []
        bottom = []
        top_tots = [0,0]
        bot_tots = [0,0]
        for i in range(0, len(values)):
            if values[i][m] > split:
                top.append(values[i][-1])
            else:
                bottom.append(values[i][-1])
        for i in range(0, len(top)):
            if top[i] == 'g':
                top_tots[0]+=1
            else:
                top_tots[1]+=1
        for i in range(0, len(bottom)):
            if bottom[i] == 'g':
                bot_tots[0]+=1
            else:
                bot_tots[1]+=1
        top_thing = self.prob_val(top_tots[0], top_tots[1])
        bot_thing = self.prob_val(bot_tots[0], bot_tots[1])

        w_right = len(top)/vals
        w_left = len(bottom)/vals

        return (w_right * top_thing + w_left * bot_thing)
    
    #determines a probability value that is the sum of the
    #probability of g within the list sqaured and the probability of b
    #within the list squared
    #this is done to produce a value that incorporates both the
    #percentage of g and b in the list
    def prob_val(self, totg, totb):
        n = totg + totb
        if n == 0:
            return -1
        pg = totg/n
        pb = totb/n
        return (pg**2 + pb**2)
        
    #determines the best split value given the m values selected
    #uses above functions to compute best splits for each of the m
    #features, and then compares these splits for a best of the best
    #returns the split value and index for which of the m features is used
    def get_split(self, values, rands, m):
        splits = []
        bestsplit = 0
        temp = 0
        final = 0
        index = 0
        for i in range(0, m):
            for j in range(0, len(values)):
                split = values[j][i]
                temp = self.get_maj_percent(split, values[:], i)
                if temp > bestsplit:
                    bestsplit = temp
            splits.append(bestsplit)
            bestsplit = 0
        for i in range(0, len(splits)):
            if splits[i] > final:
                final = splits[i]
                index = rands[i]
        return final, index

    #used to determine the majority presence of b or g in a list at leaf
    #nodes, setting 'x' if the list is empty and thus the prediction is
    #that there will be no data that fits at that node
    def maj_bg(self, values):
        b = 0
        g = 0
        for i in range(0, len(values)):
            if values[i][-1] == 'b':
                b+=1
            else:
                g+=1
        if b>=g>0:
            return 'b'
        elif g>0:
            return 'g'
        else:
            return 'x'

    #builds a decision tree by recursively creating nodes until the depth
    #parameter is met for the tree or a perfect tree is found
    #if the list has less than the min amount of samples and the depth is
    #at its limit, then the nodes created are leaves
    def build(self, values, depth, rands):
        if len(values) > self.minsamples and depth < self.maxdepth:
            bestsplit, index = self.get_split(values[:], rands, len(rands))
            leftvalues = []
            rightvalues = []
            split_index = 0
            for i in range(0, len(rands)):
                if rands[i] == index:
                    split_index = i
            for i in range(0, len(values)):
                if values[i][split_index] > bestsplit:
                    rightvalues.append(values[i])
                else:
                    leftvalues.append(values[i])
            left = self.build(leftvalues[:], depth+1, rands)
            right = self.build(rightvalues[:], depth+1, rands)
            return Node(values=values[:], left=left, right=right, split_m=index, split_val=bestsplit)
        else:
            x = self.maj_bg(values)
            return Node(values=values[:], leaf=True, predictor=x)
    
    #creates a tree by setting the root to be the resulting node
    #at the root of the built tree
    def create_tree(self, values, rands):
        self.root = self.build(values[:], 0, rands)

    #tests within a tree by comparing the test instances values to the
    #split values at each node, and getting the prediction when a leaf
    #is reached
    def test_instance(self, thetree, instance):
        if thetree.leaf == True:
            if thetree.predictor == 'g':
                return thetree.predictor
            elif thetree.predictor == 'b':
                return thetree.predictor
            else:
                return thetree.predictor

        if instance[thetree.split_m] >= thetree.split_val:
            return(self.test_instance(thetree.right, instance[:]))
        
        else:
            return(self.test_instance(thetree.left, instance[:]))