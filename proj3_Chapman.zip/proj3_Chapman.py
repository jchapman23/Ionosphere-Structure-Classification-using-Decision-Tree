#Josh Chapman
#COM 307 Machine Learning/Data Mining
#Project 3
#10/22/2021

import pandas as pd
from random import randrange
from Forest import Forest

df = pd.read_csv(r'C:\Users\joshuah\Documents\CS\COM307\proj_3\ionosphere.data')

#gets b or g vals for each instance in order
enrichment_list = []
for i in range(0, len(df)):
    enrichment_list.append(df.iloc[i][-1])

#function to check if thing is in a list
def isNotIn(thing, list):
    for i in range(0, len(list)):
        if thing == list[i]:
            return False
    return True

#selects m random, novel variables from the 34 possible features
#returns a list of m indices
def select_m(m):
    finalm = []
    while len(finalm) != m:
        rand = randrange(0, 34)
        if isNotIn(rand, finalm):
            finalm.append(rand)
    return finalm

#retrieves m random values from the database, placing them in a list
#of size [n][m+1], with the +1 coming from the enrichment value for each
#of the n instances being included in each list of m values
def get_vals(m):
    biglist = []
    temp = []
    rands = select_m(m)
    for i in range(0, len(df)):
        for j in range(0, len(rands)):
            temp.append(df.iloc[i][rands[j]])
        biglist.append(temp)
        temp = []
    for i in range(0, len(df)):
        biglist[i].append(enrichment_list[i])
    return biglist, rands

def main():
    #get m values
    vals, rands = get_vals(15)

    #create forest with 5 trees
    forest = Forest()
    forest.build_forest(vals, rands, 20)

    #pull test instance from list of 350 instances, print its enrichment value for comparision
    temp = []
    for i in range(0, len(df.iloc[0])):
        temp.append(df.iloc[0][i])
    print(temp[-1])

    #test the test instance against the forest
    forest.test_forest(temp)

    #uncomment below to see the prediction values returned in a list from
    #the trees
    print(forest.returns)

    #prints a script prediction
    forest.return_prediction()
main()